Action Replay Code Manager DSi Version- Readme.txt
--------------------------------------------------

Introduction
------------

Congratulations on your purchase of Datel�s Action Replay DSi.
This ingenious device is your key to the exciting world of
unauthorised cheat codes on your favourite DS games and is
fully compatible with the DS, DS Lite and DSi consoles.

Action Replay Code Manager is a PC software application that is
included with Action Replay DSi. Use this software to instantly
download new codes from the Codejunkies server and copy them to
your Action Replay cartridge via USB lead.


Minimum System Requirements
---------------------------

Computer / Processor	1GHz+ processor recommended
Communication		Internet connection
			USB Port (USB 2.0 highly recommended)
Operating System	Windows� XP Home or XP Pro.  
Memory			256Mb RAM
Install size: 		10MB of free hard-disk space for program
			installation plus additional hard drive
 			space for storing codes.
Display 		800X600 SVGA or higher, True Colour
Drive			CD-ROM drive (for installation)


Important information
---------------------

Unlike previous versions of Action Replay DS, the  Action Replay
cartridge should not be connected to your DS when you connect it to
your PC for use with Action Replay Code Manager.


Updating the Software
---------------------

When you first install Action Replay Code Manager it is highly
recommended that you ensure it is up-to-date by clicking the
'Update Software' button on the main menu.  This will download
any software updates for the PC application and for the Action
Replay DS firmware.


Version History
---------------

1.00	First release
1.01 	Signed Vista 32/64 USB drivers
1.02	Image update
1.03	Updated restore Images for v1.25 and v1.40 of the DSi software
1.04    Updated to work with DSi hardware supporting different types of flash chips
1.05	Updated to be hardware independant (+ multiple file delete bug fixed) + minor bug fixes
1.06	Updated to be 3DS compatible (with appropriate hardware)


-----------------------------------------------
** Note : For Windows Vista and Windows 7 users
-----------------------------------------------

Under certain circumstances, you may need to manually install the Action Replay DSi drivers as explained below:

	 1. View the Action Replay DSi icon within Device Manager under the section �Other Devices�
	 2. Double click the Action Replay DSi icon
	 3. Select �Driver�
	 4. Select �Update Driver�
	 5. Select �Browse my computer for the driver software�
	 6. Select �Let me pick from a list of device drivers on my computer�
	 7. Highlight �Show all Devices�
	 8. Select �Next�
	 9. Select �Have Disk�
	10. With the DSi Action Replay Code Manager PC software disc inserted select �Browse�
	11. From the left of the shown screen select �Computer�
	12. Double click your CD drive
	13. Highlight the file named �dsiarhwprog� if you are using a 32bit release of Windows or 
		highlight the file named �dsiarhwprog_x64� if you are using a 64bit release of Windows
	14. Select �Open�
	15. Select �OK�
	16. Select �Next�
	17. If you are shown a message which asks you to confirm the installation of the driver/software, 
		select the button to confirm the installation

Your Action Replay Dsi should now be recognised by your computer and you can use it from within the Code Manager software.
If you are still experiencing any difficulties getting your Action Replay Dsi to work then please visit the support section
at www.codejunkies.com
